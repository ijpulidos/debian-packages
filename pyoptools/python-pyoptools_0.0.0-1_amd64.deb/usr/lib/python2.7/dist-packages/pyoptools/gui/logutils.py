''' Logging utilities
'''
### Example at http://antonym.org/node/76
import logging


