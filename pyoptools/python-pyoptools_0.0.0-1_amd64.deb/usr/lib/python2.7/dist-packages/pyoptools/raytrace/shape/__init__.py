
from shape import * 
from rectangular import *
from circular import *
from triangular import *
from polygon import *
__all__=["Shape",
         "Circular",
         "Rectangular",
         "Triangular",
         "Polygon"]
