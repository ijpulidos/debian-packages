if __name__ == '__main__':
    from IPython.terminal.console import app
    app.launch_new_instance()
