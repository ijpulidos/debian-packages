"""Deprecated; import from IPython.lib.lexers instead."""

from IPython.lib.lexers import *
